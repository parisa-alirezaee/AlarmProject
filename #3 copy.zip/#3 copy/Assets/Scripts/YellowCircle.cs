﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class YellowCircle : MonoBehaviour {
	void OnCollisionEnter (Collision col)
	{
		if(col.gameObject.name.Contains("red") || col.gameObject.name.Contains("yellow"))
		{
			Destroy(col.gameObject);
		}
	}
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
