﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Text;
using System.IO;

public class Calibration : MonoBehaviour {
	private GameObject patientMonitor;
	private ClinicalScenario monitor;
	private GameObject distractionGame;
	private DistractionTask distractor;
	private VibrationGenerator VG;
	public Slider band1Amp;
	public Slider band2Amp;
	public Slider band3Amp;
	public Text band1;
	public Text band2;
	public Text band3;
	public Text title;
	public Button feel1;
	public Button feel2;
	public Button feel3;
	public Button submit;

	// Use this for initialization
	void Start () {
		patientMonitor = GameObject.Find ("PatientMonitor");
		distractionGame = GameObject.Find ("DistractionTask");
		monitor = patientMonitor.GetComponent<ClinicalScenario> ();
		distractor = distractionGame.GetComponent<DistractionTask> ();
		VG = this.GetComponent<VibrationGenerator> ();
		band1.gameObject.SetActive (false);
		band2.gameObject.SetActive (false);
		band3.gameObject.SetActive (false);
		title.gameObject.SetActive (false);
		band1Amp.gameObject.SetActive (false);
		band2Amp.gameObject.SetActive (false);
		band3Amp.gameObject.SetActive (false);
		feel1.gameObject.SetActive (false);
		feel2.gameObject.SetActive (false);
		feel3.gameObject.SetActive (false);
		submit.gameObject.SetActive (false);

        if (distractor.caliberation) {
			band1.gameObject.SetActive (true);
			band2.gameObject.SetActive (true);
			band3.gameObject.SetActive (true);
			title.gameObject.SetActive (true);
			band1Amp.gameObject.SetActive (true);
			band2Amp.gameObject.SetActive (true);
			band3Amp.gameObject.SetActive (true);
			feel1.gameObject.SetActive (true);
			feel2.gameObject.SetActive (true);
			feel3.gameObject.SetActive (true);
			submit.gameObject.SetActive (true);
			feel1.onClick.AddListener (feel1Pressed);
			feel2.onClick.AddListener (feel2Pressed);
			feel3.onClick.AddListener (feel3Pressed);
			submit.onClick.AddListener (submitPressed);
		}
    }

	void feel1Pressed(){
		StartCoroutine(VG.BzzForCalibration(4, band1Amp.value));
		print (band1Amp.value);
	}
	void feel2Pressed(){
		StartCoroutine(VG.BzzForCalibration(1, band2Amp.value));
	}
	void feel3Pressed(){
		StartCoroutine(VG.BzzForCalibration(0, band3Amp.value));
	}
	void submitPressed(){
		string filePath = Application.dataPath + "/Data/" + distractor.subjectID + "/" + distractor.subjectID + "_" + "Amps.csv";
		StreamWriter sw = System.IO.File.CreateText (filePath);

		StringBuilder sb = new StringBuilder(); 
		sb.AppendLine (band1Amp.value.ToString());
		sb.AppendLine (band2Amp.value.ToString());
		sb.AppendLine (band3Amp.value.ToString());
		sw.WriteLine (sb);
		sw.Close (); 
		submit.GetComponentInChildren<Text>().text = "All Good!";
        print("Calibration Completed!");
	}

}
