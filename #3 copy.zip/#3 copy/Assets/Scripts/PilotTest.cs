﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using UnityEngine.UI;
//using System.Text;
//using System.IO;
//
//public class PilotTest : MonoBehaviour {
//
//	private int iteration = 0;
//	private int iterationV = 0;
//	private string correctType = "CR";
//	private string correctLevel = "CR";
//	private string responseType = "RS";
//	private string responseLevel = "RS";
//	private int whichVibration = 0;
//	private float beginningOfVibration = 0;
//	[SerializeField] private AudioClip[] vibrations; //tactons version #1
//	[SerializeField] private AudioClip[] vibrations2; //tactons version #2
//	[SerializeField] private AudioClip[] otherSounds; //othersounds
//	private AudioSource vibration;
//	private AudioSource vibration2;
//	private AudioSource otherSound;
//	private bool once = false;
//
//	public int a; public int b; public int c; public int d;
//	private int[] latinSq;
//	private int tacton_version = 0;
//	private List <string> output;
//
//	private List <int> scenarios;
//	private List <int> scenariosV1;
//
//	public Button HR_Input;
//	public Button BP_Input;
//	public Button O2_Input;
//	public Text T1;
//	public Text T2;
//	public Text T3;
//	private Button HR;
//	private Button BP;
//	private Button O2;
//
//	public int subjectID = 0;
//
//	private float SelLev = 0.3f;
//	private int i = 0;
//	//	private float F = 175f;
//	private float F = 170f/6f;
//	private VibrationGenerator VG;
//	private float score = 0f;
//	private float accuracy = 0f;
//	private int version = 0;
//
//	void Start () {
//		SetLatinSquare ();
//		tacton_version = latinSq[version];
//		VG = this.GetComponent<VibrationGenerator>();
//		RandomScenariosGenerator ();
//		print (scenarios.Count);
//		output = new List<string> ();
//		vibration = GetComponent<AudioSource>();
//		vibration2 = GetComponent<AudioSource>();
//		otherSound = GetComponent<AudioSource>();
//
//		HR = HR_Input.GetComponent<Button>();
//		BP = BP_Input.GetComponent<Button>();
//		O2 = O2_Input.GetComponent<Button>();
//
//		HR.onClick.AddListener(HR_pressed);
//		BP.onClick.AddListener(BP_pressed);
//		O2.onClick.AddListener(O2_pressed);
//
//		tacton_version = latinSq[version];	
//		//StartCoroutine (TheLittleTraining ());
//
//		StartCoroutine (KeepPlayingTrials ());
//	}
//
//	void Savecsv() {
//		string filePath = Application.dataPath +"/Data/Pilot/" + "subject" + subjectID + ".csv";
//		StreamWriter sw = System.IO.File.CreateText (filePath);
//
//		StringBuilder sb = new StringBuilder(); 
//		for (int n = 0; n < output.Count; n++) {
//			sb.AppendLine (output[n]);  
//		}
//		sw.WriteLine (sb);
//		sw.Close ();        
//	}
//
//	void SetLatinSquare(){
//		latinSq = new int [7];
//		latinSq [0] = a; latinSq [1] = b; latinSq [2] = c; 
//		latinSq [3] = c; latinSq [4] = b; latinSq [5] = a; 
//		latinSq [6] = d; 
//	}
//
//	//3 scenarios
//	void RandomScenariosGenerator(){
//		scenarios = new List<int> ();
//		for (int n = 0; n < 10; n++) {
//			scenariosV1 = new List<int> ();
//			for (int j = 0; j < 3; j++) {
//				int scNum = Random.Range (1, 4);
//				while (scenariosV1.Contains (scNum)) {
//					scNum = Random.Range (1, 4);
//				}
//				scenariosV1.Add (scNum);
//			}
//			for (int j = 0; j < 3; j++) {
//				scenarios.Add (scenariosV1 [j]);
//			}
//		}
//
////		for (int j = 0; j < scenarios.Count; j++) {
////			print (scenarios [j]);
////		}
//	}
//		
//	IEnumerator TheLittleTraining(){
//		HR_Input.gameObject.SetActive (false);
//		BP_Input.gameObject.SetActive (false);
//		O2_Input.gameObject.SetActive (false);
//		T1.gameObject.SetActive (false);
//		T2.gameObject.SetActive (false);
//		T3.gameObject.SetActive (false);
//		yield return new WaitForSeconds (1f);
//		T1.text = "...TRAINING...";
//		T1.gameObject.SetActive (true);
//		yield return new WaitForSeconds (1f);
//		T2.text = "You will experience each vibration type TWICE!";
//		T2.gameObject.SetActive (true);
//		yield return new WaitForSeconds (2.5f);
//		T1.gameObject.SetActive (false);
//		T2.gameObject.SetActive (false);
//
//		for (int m = 0; m < 2; m++) {
//			T1.gameObject.SetActive (false);
//			T2.gameObject.SetActive (false);
//			yield return new WaitForSeconds (1f);
//			T1.text = "Heart Rate";
//			T1.gameObject.SetActive (true);
//			T2.text = "3";
//			T2.gameObject.SetActive (true);
//			yield return new WaitForSeconds (1f);
//			T2.text = "2";
//			yield return new WaitForSeconds (1f);
//			T2.text = "1";
//			yield return new WaitForSeconds (1f);
//			T2.text = "0";
//			StartCoroutine (VibrateHR ("training"));
//			yield return new WaitForSeconds (2f);
//
//			T1.gameObject.SetActive (false);
//			T2.gameObject.SetActive (false);
//			yield return new WaitForSeconds (1f);
//			T1.text = "Blood Pressure";
//			T1.gameObject.SetActive (true);
//			T2.text = "3";
//			T2.gameObject.SetActive (true);
//			yield return new WaitForSeconds (1f);
//			T2.text = "2";
//			yield return new WaitForSeconds (1f);
//			T2.text = "1";
//			yield return new WaitForSeconds (1f);
//			T2.text = "0";
//			StartCoroutine (VibrateBP ("training"));
//			yield return new WaitForSeconds (2f);
//
//			T1.gameObject.SetActive (false);
//			T2.gameObject.SetActive (false);
//			yield return new WaitForSeconds (1f);
//			T1.text = "Oxygen";
//			T1.gameObject.SetActive (true);
//			T2.text = "3";
//			T2.gameObject.SetActive (true);
//			yield return new WaitForSeconds (1f);
//			T2.text = "2";
//			yield return new WaitForSeconds (1f);
//			T2.text = "1";
//			yield return new WaitForSeconds (1f);
//			T2.text = "0";
//			StartCoroutine (VibrateO2 ("training"));
//			yield return new WaitForSeconds (2f);
//		}
//
//		T1.gameObject.SetActive (false);
//		T2.gameObject.SetActive (false);
//		yield return new WaitForSeconds (0.5f);
//		T1.text = "Now you will begin the main test.";
//		yield return new WaitForSeconds (2f);
//		T1.gameObject.SetActive (true);
//		T2.text = "when the buttons appear, pay attention to the vibration and select the correct type";
//		T2.gameObject.SetActive (true);
//		yield return new WaitForSeconds (6f);
//
//		T1.gameObject.SetActive (false);
//		T2.gameObject.SetActive (false);
//		HR_Input.gameObject.SetActive (true);
//		BP_Input.gameObject.SetActive (true);
//		O2_Input.gameObject.SetActive (true);
//		T3.text = "Choose the correct type by clicking on the buttons.";
//		T3.gameObject.SetActive (true);
//		yield return new WaitForSeconds (4f);
//		StartCoroutine(KeepPlayingTrials ());
//		yield break;
//	}
//		
//	void HR_pressed(){
//		print (" PRESSED");
//		responseType = "HR";
//		output.Add ("respose: " + responseType);
//		output.Add ("time: " + (Time.fixedTime - beginningOfVibration).ToString());
//		StartCoroutine(KeepPlayingTrials ());
//		print ("responded to type");
//	}
//	void BP_pressed(){
//		print (" PRESSED");
//		responseType = "BP";
//		output.Add ("respose: " + responseType);
//		output.Add ("time: " + (Time.fixedTime - beginningOfVibration).ToString ());
//		StartCoroutine(KeepPlayingTrials ());
//		print ("responded to type");
//	}
//	void O2_pressed(){
//		print (" PRESSED");
//		responseType = "O2";
//		output.Add ("respose: " + responseType);
//		output.Add ("time: " + (Time.fixedTime - beginningOfVibration).ToString ());
//		StartCoroutine(KeepPlayingTrials ());
//		print ("responded to type");
//	}
//
//	IEnumerator VibrateHR	(string level)
//	{
//		correctType = "HR";
//		if (level != "training")
//			output.Add ("correct: " + correctType + " ");
//		if (tacton_version == 1) {
//			if (level != "training")
//				iterationV++;
//			vibration.clip = vibrations [0]; //HR-V1 i
//			vibration.Play ();
////			yield return new WaitForSeconds (vibration.clip.length + 0.5f);
////			PlayLevel (level);
//		}
//
//		if (tacton_version == 2) {
//			vibration.volume = 0.8f;
//			if (level != "training")
//				iterationV++;
//			vibration2.clip = vibrations2 [0]; //HR-V2 i
//			vibration2.Play ();
////			yield return new WaitForSeconds (vibration2.clip.length + 0.5f);
////			PlayLevel (level);
//		}
//
//		if (tacton_version == 3) {
//			if (level != "training")
//				iterationV++;
//			StartCoroutine (VG.VibrateHR(0, SelLev, F, F));
////			yield return new WaitForSeconds (SelLev*3);
////			PlayLevel (level);
//		}
//
//		yield break;
//	}
//		
//	IEnumerator VibrateBP	(string level)
//	{
//		correctType = "BP";
//		if (level != "training")
//			output.Add ("correct: " + correctType + " ");
//		if (tacton_version == 1) {
//			if (level != "training")
//				iterationV++;
//			vibration.clip = vibrations [1]; //BP-V1 i
//			vibration.Play ();
////			yield return new WaitForSeconds (vibration.clip.length + 1);
////			PlayLevel (level);
//		}
//		if (tacton_version == 2) {
//			vibration.volume = 0.8f;
//			if (level != "training")
//				iterationV++;
//			vibration2.clip = vibrations2 [1]; //BP-V2 i
//			vibration2.Play ();
////			yield return new WaitForSeconds (vibration2.clip.length + 1);
////			PlayLevel (level);
//		}
//		if (tacton_version == 3) {
//			if (level != "training")
//				iterationV++;
//			StartCoroutine (VG.VibrateBP(0, SelLev, F, F, F));
////			yield return new WaitForSeconds (SelLev*4);
////			PlayLevel (level);
//		}
//		yield break;
//	}
//	IEnumerator VibrateO2	(string level)
//	{
//		correctType = "O2";
//		if (level != "training")
//			output.Add ("correct: " + correctType);
//		if (tacton_version == 1) {
//			if (level != "training")
//				iterationV++;
//			vibration.clip = vibrations [2]; //O2-V1 i
//			vibration.Play ();
////			yield return new WaitForSeconds (vibration.clip.length + 1);
////			PlayLevel (level);
//		}
//		if (tacton_version == 2) {
//			vibration.volume = 0.8f;
//			if (level != "training")
//				iterationV++;
//			vibration2.clip = vibrations2 [2]; //O2-V2 i
//			vibration2.Play ();
////			yield return new WaitForSeconds (vibration2.clip.length + 1);
////			PlayLevel (level);
//		}
//		if (tacton_version == 3) {
//			if (level != "training")
//				iterationV++;
//			StartCoroutine (VG.VibrateO2(0, SelLev, F, F, F));
////			yield return new WaitForSeconds (SelLev*5);
////			PlayLevel (level);
//		}
//
//
//		yield break;
//	}
//
//
//	bool AccuracyIsHigh(){
//		if (correctType == responseType) {
//			score++;
//		}
//		accuracy = (score / iterationV) * 100f;
//
//		if (iterationV < 15) {
//			return false;
//		}
//		if (iterationV >= 15 && accuracy > 80f) {
//			return true;
//		}
//		return false;
//	}
//
//
//	IEnumerator KeepPlayingTrials(){
//		yield return new WaitForSeconds (0.8f);
//
//		if (AccuracyIsHigh () || iterationV > 29) { //next set of tactons
//			output.Add ("=======");
//			output.Add ("Iteration " + "V#" + tacton_version + " : " + iterationV);
//			output.Add ("Accuracy : " + "V#" + tacton_version + " : " + accuracy);
//			accuracy = 0;
//			iterationV = 0;
//			score = 0;
//			version++;
//			RandomScenariosGenerator();
//			tacton_version = latinSq[version];
//			if (tacton_version == 100) { //the game is over!
//				HR_Input.gameObject.SetActive (false);
//				BP_Input.gameObject.SetActive (false);
//				O2_Input.gameObject.SetActive (false);
//				T1.gameObject.SetActive (false);
//				T2.gameObject.SetActive (false);
//				T3.gameObject.SetActive (false);
//				T1.text = "GAME OVER! :))";
//				T1.gameObject.SetActive (true);
//				output.Add ("Iteration: " + iteration);
//				Savecsv ();
//			} 
//			else {
//				StartCoroutine (TheLittleTraining());
//			}
//		}
//		else { //playing the next trial of the same tacton version
//			responseType = " ";
//			responseLevel = " ";
//			output.Add ("-----");
//			beginningOfVibration = Time.fixedTime;
//			whichVibration = scenarios [iterationV];
//			iteration++;
//			once = true;
//		}
//		yield break;
//	}
//	void Update(){
//		if (whichVibration == 1 && once) {
//			StartCoroutine (VibrateHR (""));
//			once = false;
//		}
//		if (whichVibration == 2 && once) {
//			StartCoroutine (VibrateBP (""));
//			once = false;
//		}
//		if (whichVibration == 3 && once) {
//			StartCoroutine (VibrateO2 (""));
//			once = false;
//		}
//
//
////		if (Input.GetKeyDown (KeyCode.B)) {
////			vibration.clip = vibrations [0]; //HR-V1 i
////			vibration.Play ();
////		}
////		if (Input.GetKeyDown (KeyCode.N)) {
////			vibration.volume = 0.8f;
////			vibration.clip = vibrations2 [0]; //HR-V2 i
////			vibration.Play ();
////		}
////		if (Input.GetKeyDown (KeyCode.M)) {
////			StartCoroutine (VG.VibrateHR(0, SelLev, F, F));
////		}
//			
//
//		if (Input.GetKeyDown (KeyCode.S)) {
//			Savecsv ();
//		}
//	}
//}
