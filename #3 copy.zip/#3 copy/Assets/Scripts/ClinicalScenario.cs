﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Text;
using System.IO;

public class ClinicalScenario : MonoBehaviour
{
    private GameObject distractionGame;
    private DistractionTask distractor;
    public GameObject RespondingButtons;
    public GameObject texts;

    public Text HR;
    public Text BP;
    public Text O2;
    public Text echoResponse;
    private float HRValue; 
    private float BPValue;
    private float O2Value;

    private VibrationGenerator VG;
    [SerializeField] private AudioClip[] alarms;
    public AudioSource audio_alarm;
    public AudioSource message;

    private int iteration = 0;
    public string correctAnswer = "";
    public float beginningOfAlarmTime;
    public float windowLength;
    public bool alarmNow;
    private bool audAlarmNow;
    public bool correctResponse;
    public bool endNow;
    private bool firstAlarm;

    private List<string> output;
    private string cond = "";
    private bool SwipeAlarm;
    private bool PulseAlarm;
    private bool Graphical;
    private bool SimulAlarm;
    bool constAudAlarmNow = false;
    public GameObject idle;
    public RectTransform Indicator;

    void Start()
    {
        texts = GameObject.Find("VitalSigns");
        distractionGame = GameObject.Find("DistractionTask");
        distractor = distractionGame.GetComponent<DistractionTask>();
        VG = this.GetComponent<VibrationGenerator>();
        output = new List<string>();
        output.Add("   ");

        SwipeAlarm = distractor.One;
        PulseAlarm = distractor.Two;
        SimulAlarm = distractor.Three;
        Graphical = distractor.Four;

        ResetVitalsToNormal();
        ResetOtherTriggers();
        correctResponse = false;
        firstAlarm = true;
        RespondingButtons.SetActive(false);
        if (!distractor.trainingMode && !distractor.caliberation)
        {
            SetSelectedAmps(Application.dataPath + "/Data/" + distractor.subjectID + "/" + distractor.subjectID + "_" + "Amps.csv");
            PlaceButtons();
            StartCoroutine(ValueChange());
        }
        //idle.SetActive(true);
        idle.SetActive(false);
        Indicator.gameObject.SetActive(true);
        Indicator.gameObject.SetActive(false);
        StartCoroutine(CheckIndicator());
        StartCoroutine(ResetCorrect());
    }

    public void Savecsv()
    {
        cond = distractor.SetCondition();
        string filePath = Application.dataPath + "/Data/" + distractor.subjectID.ToString() + "/MainTask/" + "Responses_" + cond + "_" + distractor.subjectID + ".csv";
        if (System.IO.File.Exists(filePath))
        {
            filePath = Application.dataPath + "/Data/" + distractor.subjectID.ToString() + "/MainTask/" + "Responses_" + cond + "_" + (distractor.subjectID+1) + ".csv";
        }
        StreamWriter sw = System.IO.File.CreateText(filePath);

        StringBuilder sb = new StringBuilder();
        for (int n = 0; n < output.Count; n++)
        {
            sb.AppendLine(output[n]);
        }
        sw.WriteLine(sb);
        sw.Close();
    }

    void SetSelectedAmps(string file_path)
    {
        StreamReader AmpsFile = new StreamReader(file_path);
        string selectedAmp;
        selectedAmp = AmpsFile.ReadLine();
        VG.amp1 = float.Parse(selectedAmp);
        selectedAmp = AmpsFile.ReadLine();
        VG.amp2 = float.Parse(selectedAmp);
        selectedAmp = AmpsFile.ReadLine();
        VG.amp3 = float.Parse(selectedAmp);
        AmpsFile.Close();
    }
    //one value is chosen from the normal range for each vital
    public void ResetVitalsToNormal()
    {
        HRValue = 0f;
        BPValue = 0f;
        O2Value = 0f;
        HR.text = "N";
        BP.text = "N";
        O2.text = "N";
    }
    //for the training parts
    public void ResetVitalsToNormalAndShow()
    {
        HRValue = 0f;
        BPValue = 0f;
        O2Value = 0f;
        HR.text = "N";
        BP.text = "N";
        O2.text = "N";
    }
    public void ResetOtherTriggers()
    {
        endNow = false;
        alarmNow = false;
        //audAlarmNow = false;
    }
    void PlaceButtons()
    {
        RespondingButtons.SetActive(true);
        RespondingButtons.GetComponentsInChildren<Button>()[0].onClick.AddListener(HRH_Pressed);
        RespondingButtons.GetComponentsInChildren<Button>()[1].onClick.AddListener(HRL_Pressed);
        RespondingButtons.GetComponentsInChildren<Button>()[2].onClick.AddListener(BPH_Pressed);
        RespondingButtons.GetComponentsInChildren<Button>()[3].onClick.AddListener(BPL_Pressed);
        RespondingButtons.GetComponentsInChildren<Button>()[4].onClick.AddListener(O2H_Pressed);
        RespondingButtons.GetComponentsInChildren<Button>()[5].onClick.AddListener(O2L_Pressed);
    }

    //IEnumerator EchoResponse(string answer)
    //{
    //    echoResponse.gameObject.SetActive(true);
    //    echoResponse.text = "Response: " + answer;
    //    yield return new WaitForSeconds(3f);
    //    echoResponse.gameObject.SetActive(false);
    //}

    void CorrectAnswerActions(string answer)
    {
        VG.correct = true;
        print("Correct Answer!");
        constAudAlarmNow = false;
        ResetVitalsToNormal();
        ResetOtherTriggers();
        firstAlarm = true;
        //StartCoroutine(EchoResponse(answer));

        output.Add("Alarm Condition: " + correctAnswer);
        output.Add("Responded: " + answer);
        output.Add((Time.fixedTime - beginningOfAlarmTime).ToString());
        output.Add("   ");
        StopCoroutine(VibrateAlarm(answer.Substring(0, 2)));
        StopCoroutine(ConstAudioAlarm());
        //StopCoroutine(AudioAlarm());

        correctAnswer = "";

        //start again
        alarmNow = false;
        iteration++;

        if (iteration >= distractor.iteration)
        {
            print("Done");
            if (distractor.iteration != 4 && distractor.iteration != 2)
                Savecsv();
            endNow = true;
        }
    }

    void IncorrectAnswerActions(string answer)
    {
        if (correctAnswer != "")
        {
            print("Incorrect Answer: " + answer);
            output.Add("Alarm Condition: " + correctAnswer);
            output.Add("Responded: " + answer);
            output.Add((Time.fixedTime - beginningOfAlarmTime).ToString());
            //StartCoroutine(EchoResponse(answer));
        }
    }

    void HRH_Pressed()
    {
        Indicator.position = new Vector3(1346, 992, 0f);
        Indicator.gameObject.SetActive(true);
        if (correctAnswer == "HRH")
        { //correct response
            CorrectAnswerActions("HR High");
        }
        else
        { //incorrect response, alarm again
            IncorrectAnswerActions("HR High");
        }
    }
    void HRL_Pressed()
    {
        Indicator.position = new Vector3(1601, 986, 0f);
        Indicator.gameObject.SetActive(true);
        if (correctAnswer == "HRL")
        { //correct response
            CorrectAnswerActions("HR Low");
        }
        else
        { //incorrect response, alarm again
            IncorrectAnswerActions("HR Low");
        }
    }
    void BPH_Pressed()
    {
        Indicator.position = new Vector3(1346, 858, 0f);
        Indicator.gameObject.SetActive(true);
        if (correctAnswer == "BPH")
        { //correct response
            CorrectAnswerActions("BP High");
        }
        else
        { //incorrect response, alarm again
            IncorrectAnswerActions("BP High");
        }
    }
    void BPL_Pressed()
    {
        Indicator.position = new Vector3(1601, 857, 0f);
        Indicator.gameObject.SetActive(true);
        if (correctAnswer == "BPL")
        { //correct response
            CorrectAnswerActions("BP Low");
        }
        else
        { //incorrect response, alarm again
            IncorrectAnswerActions("BP Low");
        }
    }
    void O2H_Pressed()
    {
        Indicator.position = new Vector3(1346, 728, 0f);
        Indicator.gameObject.SetActive(true);
        if (correctAnswer == "O2H")
        { //correct response
            CorrectAnswerActions("O2 High");
        }
        else
        { //incorrect response, alarm again
            IncorrectAnswerActions("O2 High");
        }
    }
    void O2L_Pressed()
    {
        Indicator.position = new Vector3(1601, 731, 0f);
        Indicator.gameObject.SetActive(true);
        if (correctAnswer == "O2L")
        { //correct response
            CorrectAnswerActions("O2 Low");
        }
        else
        { //incorrect response, alarm again
            IncorrectAnswerActions("O2 Low");
        }
    }


    IEnumerator VibrateAlarm(string parameter) 
    {
        if (PulseAlarm) {//double/triple pulse
            if (parameter == "HR")
            {
                StartCoroutine(VG.AlarmHRPulse());
            }
            else if (parameter == "BP")
            {
                StartCoroutine(VG.AlarmBPPulse());
            }
            else if (parameter == "O2")
            {
                 StartCoroutine(VG.AlarmO2Pulse());
            }
            yield break;
        }
        else if (SwipeAlarm) { //swipe up/down
            if (parameter == "HR")
            {
                StartCoroutine(VG.AlarmHRSwipe());
            }
            else if (parameter == "BP")
            {
                StartCoroutine(VG.AlarmBPSwipe());
            }
            else if (parameter == "O2")
            {
                StartCoroutine(VG.AlarmO2Swipe());
            }
            yield break;
        }
        else if(SimulAlarm){ //simultaneous normal rendering, 
            if (parameter == "HR")
            {
                if (firstAlarm)
                    StartCoroutine(VG.AlarmHRNew());
            }
            else if (parameter == "BP")
            {
                if(firstAlarm)
                    StartCoroutine(VG.AlarmBPNew());
            }
            else if (parameter == "O2")
            {
                if (firstAlarm)
                    StartCoroutine(VG.AlarmO2New());
            }
            yield break;
        }
    }

    IEnumerator ConstAudioAlarm(){
        while (!constAudAlarmNow)
            yield return null;

        audio_alarm.clip = alarms [0];
        audio_alarm.Play ();
        yield return new WaitForSeconds (windowLength*3);

        StartCoroutine (ConstAudioAlarm ());
    }

    IEnumerator ValueChange()
    {
        if (HRValue == 0f)
        { //normal
            print("HR Nomal");
            //HR.text = "N";
            if (SwipeAlarm || PulseAlarm)
            {
                StartCoroutine(VG.VibrateBeep(4)); //vibrate normal HR
            }
            else if (SimulAlarm && !alarmNow)
            {
                StartCoroutine(VG.VibrateBeepSimul());
            }

            int random = Random.Range(0, 2);
            if (random == 0)
            {
                HRValue = 0.5f;
                HR.text = "N";
            }
            else if (random == 1)
            {
                HRValue = -0.5f;
                HR.text = "N";
            }
        }
        else if (HRValue == 0.5f)
        { //half-high
            print("HR Nomal");
            //HR.text = "N";
            if (SwipeAlarm || PulseAlarm)
            {
                StartCoroutine(VG.VibrateBeep(4)); //vibrate normal HR
            }
            else if (SimulAlarm && !alarmNow)
            {
                StartCoroutine(VG.VibrateBeepSimul());
            }

            int random = Random.Range(0, 2);
            if (random == 0)
            {
                HRValue = 1f;
                HR.text = "N";
            }
            else if (random == 1)
            {
                HRValue = 0f;
                HR.text = "N";
            }
        }
        else if (HRValue == -0.5f)
        { //half-low
            print("HR Nomal");
            //HR.text = "N";
            if (SwipeAlarm || PulseAlarm)
            {
                StartCoroutine(VG.VibrateBeep(4)); //vibrate normal HR
            }
            else if (SimulAlarm && !alarmNow)
            {
                StartCoroutine(VG.VibrateBeepSimul());
            }


            int random = Random.Range(0, 2);
            if (random == 0)
            {
                HRValue = 0f;
                HR.text = "N";
            }
            else if (random == 1)
            {
                HRValue = -1f;
                HR.text = "N";
            }
        }
        else if (HRValue == 1)
        { //high
            print("HR HIGH");
            correctAnswer = "HRH";
            O2Value = 0;
            BPValue = 0;
            alarmNow = true;
            if (Graphical)
            {
                HR.text = "↑";
                constAudAlarmNow = true;
                StartCoroutine(ConstAudioAlarm());
            }
            else
            {
                VG.alarmLevel = "H";
                StartCoroutine(VibrateAlarm("HR"));
            }
            if (firstAlarm)
                beginningOfAlarmTime = Time.fixedTime;
            firstAlarm = false;
        }
        else if (HRValue == -1)
        { //low
            print("HR LOW");
            correctAnswer = "HRL";
            O2Value = 0;
            BPValue = 0;
            alarmNow = true;
            if (Graphical)
            {
                HR.text = "↓";
                constAudAlarmNow = true;
                StartCoroutine(ConstAudioAlarm());
            }
            else
            {
                VG.alarmLevel = "L";
                StartCoroutine(VibrateAlarm("HR"));
            }

            if (firstAlarm)
                beginningOfAlarmTime = Time.fixedTime;
            firstAlarm = false;
        }

        yield return new WaitForSeconds(windowLength);

        if (BPValue == 0f)
        { //normal
            print("BP Normal");
            //BP.text = "N";
            if (SwipeAlarm || PulseAlarm)
            {
                StartCoroutine(VG.VibrateBeep(1)); //vibrate normal BP
            }
            else if (SimulAlarm && !alarmNow)
            {
                StartCoroutine(VG.VibrateBeepSimul());
            }


            int random = Random.Range(0, 2);
            if (random == 0)
            {
                BPValue = 0.5f;
                BP.text = "N";
            }
            else if (random == 1)
            {
                BPValue = -0.5f;
                BP.text = "N";
            }
        }
        else if (BPValue == 0.5f)
        { //half-high
            print("BP Normal");
            //BP.text = "N";
            if (SwipeAlarm || PulseAlarm)
            {
                StartCoroutine(VG.VibrateBeep(1)); //vibrate normal BP
            }
            else if (SimulAlarm && !alarmNow)
            {
                StartCoroutine(VG.VibrateBeepSimul());
            }

            int random = Random.Range(0, 2);
            if (random == 0)
            {
                BPValue = 1f;
                BP.text = "N";
            }
            else if (random == 1)
            {
                BPValue = 0f;
                BP.text = "N";
            }
        }
        else if (BPValue == -0.5f)
        { //half-low
            print("BP Normal");
            //BP.text = "N";
            if (SwipeAlarm || PulseAlarm)
            {
                StartCoroutine(VG.VibrateBeep(1)); //vibrate normal BP
            }
            else if (SimulAlarm && !alarmNow)
            {
                StartCoroutine(VG.VibrateBeepSimul());
            }

            int random = Random.Range(0, 2);
            if (random == 0)
            {
                BPValue = 0f;
                BP.text = "N";
            }
            else if (random == 1)
            {
                BPValue = -1f;
                BP.text = "N";
            }
        }
        else if (BPValue == 1)
        { //high
            print("BP HIGH");
            correctAnswer = "BPH";
            HRValue = 0;
            O2Value = 0;
            alarmNow = true;
            if (Graphical)
            {
                BP.text = "↑";
                constAudAlarmNow = true;
                StartCoroutine(ConstAudioAlarm());
            }
            else
            {
                VG.alarmLevel = "H";
                StartCoroutine(VibrateAlarm("BP"));
            }
            if (firstAlarm)
                beginningOfAlarmTime = Time.fixedTime;
            firstAlarm = false;
        }
        else if (BPValue == -1)
        { //low
            print("BP LOW");
            correctAnswer = "BPL";
            HRValue = 0;
            O2Value = 0;
            alarmNow = true;
            if (Graphical)
            {
                BP.text = "↓";
                constAudAlarmNow = true;
                StartCoroutine(ConstAudioAlarm());
            }
            else
            {
                VG.alarmLevel = "L";
                StartCoroutine(VibrateAlarm("BP"));
            }

            if (firstAlarm)
                beginningOfAlarmTime = Time.fixedTime;
            firstAlarm = false;

        }
        yield return new WaitForSeconds(windowLength);

        if (O2Value == 0f)
        { //normal
            //O2.text = "N";
            print("O2 Normal");
            if (SwipeAlarm || PulseAlarm)
            {
                StartCoroutine(VG.VibrateBeep(0)); //vibrate normal O2
            }
            else if (SimulAlarm && !alarmNow)
            {
                StartCoroutine(VG.VibrateBeepSimul());
            }

            int random = Random.Range(0, 2);
            if (random == 0)
            {
                O2Value = 0.5f;
                O2.text = "N";
            }
            else if (random == 1)
            {
                O2Value = -0.5f;
                O2.text = "N";
            }
        }
        else if (O2Value == 0.5f)
        { //half-high
            //O2.text = "N";
            print("O2 Normal");
            if(SwipeAlarm || PulseAlarm)
            {
                StartCoroutine(VG.VibrateBeep(0)); //vibrate normal O2
            }
            else if (SimulAlarm && !alarmNow)
            {
                StartCoroutine(VG.VibrateBeepSimul());
            }

            int random = Random.Range(0, 2);
            if (random == 0)
            {
                O2Value = 1f;
                O2.text = "N";
            }
            else if (random == 1)
            {
                O2Value = 0f;
                O2.text = "N";
            }
        }
        else if (O2Value == -0.5f)
        { //half-low
            //O2.text = "N";
            print("O2 Normal");
            if (SwipeAlarm || PulseAlarm)
            {
                StartCoroutine(VG.VibrateBeep(0)); //vibrate normal O2
            }
            else if (SimulAlarm && !alarmNow)
            {
                StartCoroutine(VG.VibrateBeepSimul());
            }

            int random = Random.Range(0, 2);
            if (random == 0)
            {
                O2Value = 0f;
                O2.text = "N";
            }
            else if (random == 1)
            {
                O2Value = -1f;
                O2.text = "N";
            }
        }
        else if (O2Value == 1)
        { //high
            print("O2 HIGH");
            correctAnswer = "O2H";
            HRValue = 0;
            BPValue = 0;
            alarmNow = true;
            if (Graphical)
            {
                O2.text = "↑";
                constAudAlarmNow = true;
                StartCoroutine(ConstAudioAlarm());
            }
            else
            {
                VG.alarmLevel = "H";
                StartCoroutine(VibrateAlarm("O2"));
            }
            if (firstAlarm)
                beginningOfAlarmTime = Time.fixedTime;
            firstAlarm = false;
        }
        else if (O2Value == -1)
        { //low
            print("O2 LOW");
            correctAnswer = "O2L";
            HRValue = 0;
            BPValue = 0;
            alarmNow = true;
            if (Graphical)
            {
                O2.text = "↓";
                constAudAlarmNow = true;
                StartCoroutine(ConstAudioAlarm());
            }
            else
            {
                VG.alarmLevel = "L";
                StartCoroutine(VibrateAlarm("O2"));
            }

            if (firstAlarm)
                beginningOfAlarmTime = Time.fixedTime;
            firstAlarm = false;
        }
        yield return new WaitForSeconds(windowLength);
        StartCoroutine(ValueChange());
    }

    IEnumerator CheckIndicator(){
        while(!Indicator.gameObject.active){
            yield return null;
        }
        yield return new WaitForSeconds(1.5f);
        Indicator.gameObject.SetActive(false);
        StartCoroutine(CheckIndicator());
        yield break;
    }

    IEnumerator ResetCorrect()
    {
        while (!VG.correct)
        {
            yield return null;
        }
        yield return new WaitForSeconds(1.5f);
        VG.correct = false;
        StartCoroutine(ResetCorrect());
        yield break;
    }

}