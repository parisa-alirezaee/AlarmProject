﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Text;
using System.IO;

public class DistractionTask : MonoBehaviour {
	public int subjectID;
	public bool caliberation;
    public bool trainingMode;
    public bool general;

    public bool One; //Swipe
    public bool Two; //Pulse
    public bool Three; //Simul
    public bool Four; //Graphical


    public int iteration;

	//public Text scoreText;
	private float changedColorTime;
	private float clickedTime = 0;
	private Vector3 origMousePos;
	private float circlesWidth;
	private int numberOfCircles = 9;
	public GameObject circlePrefab;
	public Material yellowColor;
	public Material redColor;
	private int clickNumbers;
	private List<string> performances;
	private string cond = "";

	private GameObject patientMonitor;
	private ClinicalScenario monitor;
	private Training training;
	private Calibration calib;
	private GameObject monitorTexts;
	public bool startNow = false;
	public Text finalMessage;

    private bool SwipeAlarm;
    private bool PulseAlarm;
    private bool Graphical;
    private bool SimulAlarm;

    void Start () {

		patientMonitor = GameObject.Find("PatientMonitor");
		training = this.GetComponent<Training>();
		calib = this.GetComponent<Calibration>();
		monitor = patientMonitor.GetComponent<ClinicalScenario>();
		monitorTexts = monitor.texts;

        SwipeAlarm = One;
        PulseAlarm = Two;
        SimulAlarm = Three;
        Graphical = Four;

        //Decide whether to have the screen or not
        if (Graphical) {
			monitorTexts.SetActive (true);
		} else {
			monitorTexts.SetActive (true);
			monitorTexts.SetActive (false);
		}

		performances = new List<string> ();
		performances.Add ("IP Scores");
        if (!trainingMode && !caliberation) {
			BeginTheGame ();
			StartCoroutine (EndTheGame());
		}
	}

	void BeginTheGame()
	{
		PlaceCircles ();
		clickedTime = Time.fixedTime;
		startNow = true;
	}

	public void RemoveCircles(){
		for (int i = 0; i < numberOfCircles; i++) {
			GameObject.Destroy (GameObject.FindGameObjectsWithTag ("yellow")[i]);
		}
		GameObject.Destroy (GameObject.FindGameObjectWithTag ("red"));
	}
	IEnumerator EndTheGame()
	{
		while (!monitor.endNow)
			yield return null;
		RemoveCircles ();
		yield return new WaitForSeconds (1f);
		finalMessage.text = "END OF THIS SECTION!";
		performances.Add("Time");
		performances.Add((Time.fixedTime).ToString());
        if(iteration != 4 && iteration != 2)
			Savecsv ();
		Time.timeScale = 0;
	}

	void Savecsv() {
		cond = SetCondition();
		string filePath = Application.dataPath + "/Data/" + subjectID.ToString() + "/DistractorTask/" + "/FittsIP_" + cond + "_" + subjectID + ".csv";
        if (System.IO.File.Exists(filePath))
        {
            filePath = Application.dataPath + "/Data/" + subjectID.ToString() + "/MainTask/" + "Responses_" + cond + "_" + (subjectID + 1) + ".csv";
        }
        StreamWriter sw = System.IO.File.CreateText (filePath);
	
		StringBuilder sb = new StringBuilder(); 
		for (int i = 0; i < performances.Count; i++) {
			sb.AppendLine(performances[i]);  
		}
	
		sw.WriteLine (sb);
		sw.Close ();
    }

    public string SetCondition()
    {
        if (PulseAlarm)
        {
            return "LegPulse";
        }
        else if (SwipeAlarm)
        {
            return "LegSwipe";
        }
        else if (SimulAlarm)
        {
            return "LegSimul";
        }
        else if (Graphical)
        {
            return "Graphical";
        }
        else
            return "";
    }

    //placing on a circular position
    Vector3 RandomCircle (Vector3 center, float radius, int i){
		float ang = 0;
		ang = i * 36;
		Vector3 pos;
		pos.x = center.x + radius * Mathf.Sin(ang * Mathf.Deg2Rad);
		pos.y = center.y + radius * Mathf.Cos(ang * Mathf.Deg2Rad);
		pos.z = center.z;
		return pos;
	}

	public void PlaceCircles(){
		prevNum = 8;
		GameObject circle;
		circlesWidth = Random.Range (0.3f, 1.4f);
		Vector3 center;
		//putting yellow circles
		for (int i = 0; i < numberOfCircles; i++) {
			circle = (GameObject)Instantiate (circlePrefab);
			circle.name = "yellow " + i;
			circle.tag = "yellow";
			circle.GetComponentInChildren<Renderer> ().material = yellowColor;
			circle.transform.localScale = new Vector3 (circlesWidth, circlesWidth, circlesWidth);
			if (trainingMode)
				circle.transform.position = new Vector3 (0f, 0f, -3.0f);
			else
				circle.transform.position = new Vector3 (-1.5f, -0.2f, -3.0f);
			

			center = circle.transform.position;
			//circle.transform.position = RandomCircle(center, 3.0f, i);
			circle.transform.position = RandomCircle(center, 4.0f, i);
			circle.transform.rotation = Quaternion.FromToRotation(Vector3.forward, center-circle.transform.position);
		}

		//putting one red circle
		circle = (GameObject)Instantiate (circlePrefab);
		circle.name = "red ";
		circle.tag = "red";
		circle.GetComponentInChildren<Renderer> ().material = redColor;
		circle.transform.localScale = new Vector3 (circlesWidth, circlesWidth, circlesWidth);
		if (trainingMode)
			circle.transform.position = new Vector3 (0f, 0f, -3.0f);
		else
			circle.transform.position = new Vector3 (-1.5f, -0.2f, -3.0f);

		center = circle.transform.position;
		//circle.transform.position = RandomCircle(center, 3.0f, 9);
		circle.transform.position = RandomCircle(center, 4.0f, 9);
		circle.transform.rotation = Quaternion.FromToRotation(Vector3.forward, center-circle.transform.position);

	}

	float DistanceBetween (Vector3 a, Vector3 b){
		return Mathf.Sqrt (Mathf.Pow ((a.x - b.x), 2) + Mathf.Pow ((a.y - b.y), 2));
	}
	int prevNum;

	void ChangeColor(GameObject clickedRed){
		origMousePos = Input.mousePosition;

		changedColorTime = Time.fixedTime;	

		if (prevNum - 4 < 0) {
			prevNum = prevNum + 5;
		} else {
			prevNum = prevNum - 4;
		}
		//prevNum = Random.Range (0, 9);
		string name = "yellow " + prevNum.ToString();
		GameObject selectedYellow = GameObject.Find(name);
		Vector3 tempPos = new Vector3 ();
		tempPos = selectedYellow.transform.localPosition;
		selectedYellow.transform.localPosition = clickedRed.transform.localPosition;
		clickedRed.transform.localPosition = tempPos;
	}


	public void ClickAndPlay(){
		float dist;
		float ID;
		float MT;
		float IP;
		Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

		RaycastHit hit;
		//this if checks, a detection of hit in an GameObject with the mouse on screen
		if(Physics.Raycast(ray, out hit, 10f))
		{
			if(hit.collider.gameObject.name.Contains("red")){
				if (clickCount < 10) {
					clickCount++;
					clickedTime = Time.fixedTime;
					//fitt's law calculations
					Ray origRay = Camera.main.ScreenPointToRay (origMousePos);
					Ray clickedRay = Camera.main.ScreenPointToRay (Input.mousePosition);
					dist = DistanceBetween (origRay.GetPoint (0), clickedRay.GetPoint (0));
					ID = Mathf.Log ((2 * dist / circlesWidth), 2);
					MT = clickedTime - changedColorTime;
					IP = (ID / MT);
//					scoreText.gameObject.SetActive (true);
//					scoreText.text = "Score:  " + Mathf.Round (IP * 10).ToString ();
					performances.Add (IP.ToString ());

				} else {
					clickCount = 1;
				}
				clickNumbers++;

				ChangeColor(hit.collider.gameObject);
			}
		}
	}
		
	int clickCount = 0;
	// Update is called once per frame
	void Update () {
		if (startNow) {
			if (Input.GetMouseButtonDown (0)) {
				ClickAndPlay ();
			}

			if (clickNumbers == numberOfCircles+1) {
				//Clear the plot to put new circles
				GameObject[] yellows = GameObject.FindGameObjectsWithTag ("yellow");

				for (int i = 0; i < yellows.Length; i++) {
					Destroy (yellows [i]);
				}
				Destroy (GameObject.FindGameObjectWithTag ("red"));
				clickNumbers = 0;

				PlaceCircles ();
			}
			if (Input.GetKey (KeyCode.S)) {
				Savecsv ();
                monitor.Savecsv();
			}
		}
	}
}



