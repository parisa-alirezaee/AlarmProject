﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VibrationGenerator : MonoBehaviour {
	public bool threebzz;
    public bool correct = false;
	private bool calibMode = false;
	private int position = 0;
	private int samplerate = 44100;
	private int amountOfChannels = 6;
	private float[] audioData;
	private float[] originalAudioData;
   private AudioClip myClip;
   public AudioSource vibration;
    public AudioSource vibration1;
    public AudioSource vibration2;
    public AudioSource vibration3;
	private float vibLength = 0.25f;
	private float frequency;
	private float amp;
	public float amp1;
	public float amp2;
	public float amp3;

	public float beginningOfVibration = 0;
	public string alarmLevel = "no alarm";


	void Start () {}

    void GenerateVib(int CH, float LEN){
		if (!calibMode) {
			if (CH == 0) {
				amp = amp3;
			}
			if (CH == 1) {
				amp = amp2;
			}
			if (CH == 4) {
				amp = amp1;
			}
		}
		myClip = AudioClip.Create("vib", samplerate * 2, amountOfChannels, samplerate, false, OnAudioRead, OnAudioSetPosition);
		audioData = new float[myClip.samples * amountOfChannels];
		originalAudioData = new float[myClip.samples * amountOfChannels];
		myClip.GetData (originalAudioData, 0);
		// Fill in the audio from the original clip into the target channel. Samples are interleaved by channel (L0, R0, L1, R1, etc).
		int originalClipIndex = 0;
		for (int i = CH; i < (audioData.Length/2)*LEN; i += amountOfChannels)
		{
			audioData[i] = originalAudioData[originalClipIndex];
			originalClipIndex += myClip.channels;
		}
		myClip.SetData (audioData, 0);
		vibration.clip = myClip;
		vibration.Play();

	}

    void OnAudioRead(float[] data)
    {
        frequency = 170 / 6;
        int count = 0;
        while (count < data.Length)
        {
            data[count] = amp * Mathf.Sin(2 * Mathf.PI * frequency * position / samplerate);
            position++;
            count++;
        }
    }
    void OnAudioSetPosition(int newPosition)
    {
        position = newPosition;
    }


    public IEnumerator BzzForCalibration(int band, float setAmp){
		calibMode = true;
		for (int i = 0; i < 4; i++) {
			amp = setAmp;
			GenerateVib(band, vibLength);
			yield return new WaitForSeconds (vibLength + 0.2f);
		}
	}

	public IEnumerator VibrateBeep(int i)
	{
		GenerateVib(i, vibLength);
		yield return new WaitForSeconds (vibLength);
		yield break;
	}

    public IEnumerator AlarmHRSwipe()
	{
		beginningOfVibration = Time.fixedTime;
		StartCoroutine (VibrateSwipe());
		yield return new WaitForSeconds (0.75f);
		if (threebzz) {
			for (int i = 0; i < 3; i++) {
				GenerateVib(4, vibLength/2);
				yield return new WaitForSeconds (vibLength);
			}
		}
		else{
			GenerateVib(4,vibLength);
		}
		yield break;
	}

	public IEnumerator AlarmBPSwipe()
	{
		beginningOfVibration = Time.fixedTime;
		StartCoroutine (VibrateSwipe());
		yield return new WaitForSeconds (0.75f);
		if (threebzz) {
			for (int i = 0; i < 3; i++) {
				GenerateVib(1, vibLength/2);
				yield return new WaitForSeconds (vibLength);
			}
		}
		else{
			GenerateVib(1,vibLength);
		}
		yield break;
	}

	public IEnumerator AlarmO2Swipe()
	{
		beginningOfVibration = Time.fixedTime;
		StartCoroutine (VibrateSwipe());
		yield return new WaitForSeconds (0.75f);
		if (threebzz) {
			for (int i = 0; i < 3; i++) {
				GenerateVib(0, vibLength/2);
				yield return new WaitForSeconds (vibLength);
			}
		}
		else{
			GenerateVib(0,vibLength);
		}
		yield break;
	}

	public IEnumerator VibrateSwipe (){
		int[] targetCh = null;
		if (alarmLevel == "H") {
			targetCh = new int [3];
			targetCh [0] = 0; targetCh [1] = 1; targetCh [2] = 4;
		}
		else if (alarmLevel == "L") {
			targetCh = new int [3];
			targetCh [0] = 4; targetCh [1] = 1; targetCh [2] = 0;
		}
		else if (alarmLevel == "no alarm") {
			targetCh = null;
			yield break;
		}

		for (int n = 0; n < targetCh.Length; n++) {
			GenerateVib(targetCh[n], vibLength);
			yield return new WaitForSeconds (vibLength - 0.065f);
		}
		alarmLevel = "no alarm";
		yield break;
	}

    public IEnumerator AlarmHRPulse()
    {
        if (alarmLevel == "L")
        {
            GenerateVib(4, 0.2f);
            yield return new WaitForSeconds(0.3f);
            GenerateVib(4, 0.2f);
        }

        else if (alarmLevel == "H")
        {
            GenerateVib(4, 0.1f);
            yield return new WaitForSeconds(0.2f);
            GenerateVib(4, 0.1f);
            yield return new WaitForSeconds(0.2f);
            GenerateVib(4, 0.1f);
        }
        yield break;
    }

    public IEnumerator AlarmBPPulse()
    {
        if (alarmLevel == "L")
        {
            GenerateVib(1, 0.2f);
            yield return new WaitForSeconds(0.3f);
            GenerateVib(1, 0.2f);
        }

        else if (alarmLevel == "H")
        {
            GenerateVib(1, 0.1f);
            yield return new WaitForSeconds(0.2f);
            GenerateVib(1, 0.1f);
            yield return new WaitForSeconds(0.2f);
            GenerateVib(1, 0.1f);
        }
        yield break;
    }

    public IEnumerator AlarmO2Pulse()
    {
        if (alarmLevel == "L")
        {
            GenerateVib(0, 0.2f);
            yield return new WaitForSeconds(0.3f);
            GenerateVib(0, 0.2f);
        }

        else if (alarmLevel == "H")
        {
            GenerateVib(0, 0.1f);
            yield return new WaitForSeconds(0.2f);
            GenerateVib(0, 0.1f);
            yield return new WaitForSeconds(0.2f);
            GenerateVib(0, 0.1f);
        }
        yield break;
    }
        
    public IEnumerator AlarmHRNew()
    {
        if (alarmLevel == "H")
        {
            for (int i = 0; i < 1000; i++)
            {
                GenerateVib(4, 0.2f); yield return new WaitForSeconds(0.3f);
                if (correct)
                    break;
            }
        }

        else if (alarmLevel == "L")
        {
            for (int i = 0; i < 1000; i++)
            {
                GenerateVib(4, 1.0f); yield return new WaitForSeconds(1.5f);
                if (correct)
                    break;
            }
        }
        yield break;
    }

    public IEnumerator AlarmBPNew()
    {
        if (alarmLevel == "H")
        {
            for (int i = 0; i < 1000; i++)
            {
                GenerateVib(1, 0.2f); yield return new WaitForSeconds(0.3f);
                if (correct)
                    break;
            }
        }

        else if (alarmLevel == "L")
        {
            for (int i = 0; i < 1000; i++)
            {
                GenerateVib(1, 1.0f); yield return new WaitForSeconds(1.5f);
                if (correct)
                    break;
            }
        }
        yield break;
    }

    public IEnumerator AlarmO2New()
    {
        if (alarmLevel == "H")
        {
            for (int i = 0; i < 1000; i++){
                GenerateVib(0, 0.2f); yield return new WaitForSeconds(0.3f);
                if (correct)
                    break;
            }
        }

        else if (alarmLevel == "L")
        {
            for (int i = 0; i < 1000; i++)
            {
                GenerateVib(0, 1.0f); yield return new WaitForSeconds(1.5f);
                if (correct)
                    break;
            }
        }
        yield break;
    }

    IEnumerator GenerateVibSimul(AudioSource AS, int CH, float LEN)
    {
        if (!calibMode)
        {
            if (CH == 0)
            {
                amp = amp3 - (amp3 / 10);
            }
            if (CH == 1)
            {
                amp = amp2 - (amp2 / 10);
            }
            if (CH == 4)
            {
                amp = amp1 - (amp1 / 10);
            }
        }
        myClip = AudioClip.Create("vib", samplerate * 2, amountOfChannels, samplerate, false, OnAudioRead, OnAudioSetPosition);
        audioData = new float[myClip.samples * amountOfChannels];
        originalAudioData = new float[myClip.samples * amountOfChannels];
        myClip.GetData(originalAudioData, 0);
        // Fill in the audio from the original clip into the target channel. Samples are interleaved by channel (L0, R0, L1, R1, etc).
        int originalClipIndex = 0;
        for (int i = CH; i < (audioData.Length / 2) * LEN; i += amountOfChannels)
        {
            audioData[i] = originalAudioData[originalClipIndex];
            originalClipIndex += myClip.channels;
        }
        myClip.SetData(audioData, 0);
        AS.clip = myClip;
        AS.Play();
        yield break;
    }

    public IEnumerator VibrateBeepSimul()
    {
        //StartCoroutine(GenerateVibSimul(vibration1, 0, vibLength));
        //StartCoroutine(GenerateVibSimul(vibration2, 1, vibLength));
        //StartCoroutine(GenerateVibSimul(vibration3, 4, vibLength));
        yield break;
    }
}
