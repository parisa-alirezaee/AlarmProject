﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Text;
using System.IO;
using UnityEngine.Video;

public class Training : MonoBehaviour {
    private VibrationGenerator VG;
    public Text T1;
    public Text T2;
    public Text T3;
    public Text T4;
    [SerializeField] private AudioClip[] messages;
    private AudioSource message;
    private GameObject patientMonitor;
    private ClinicalScenario monitor;
    private GameObject distractionGame;
    private DistractionTask distractor;
    private GameObject monitorTexts;
    public Button Next;
    public Button NormalButton;
    public GameObject Circles;
    public GameObject Leg;
    public GameObject Leg2;
    public GameObject Leg3;
    public GameObject Leg4;
    public GameObject Buttons;
    //public GameObject Buttons2;
    public int section;
    bool NormalPressed = false;

    bool HRHPressed = false;
    bool HRLPressed = false;
    bool BPHPressed = false;
    bool BPLPressed = false;
    bool O2HPressed = false;
    bool O2LPressed = false;

    private bool SwipeAlarm;
    private bool PulseAlarm;
    private bool Graphical;
    private bool SimulAlarm;


    private bool calibration;

    //public GameObject HRH_clip;
    //public GameObject HRL_clip;
    //public GameObject BPH_clip;
    //public GameObject BPL_clip;
    //public GameObject O2H_clip;
    //public GameObject O2L_clip;
    //public GameObject normal_clip;

    void Start () {
        patientMonitor = GameObject.Find ("PatientMonitor");
        distractionGame = GameObject.Find ("DistractionTask");
        monitor = patientMonitor.GetComponent<ClinicalScenario> ();
        distractor = distractionGame.GetComponent<DistractionTask> ();

        SwipeAlarm = distractor.One;
        PulseAlarm = distractor.Two;
        SimulAlarm = distractor.Three;
        Graphical = distractor.Four;

        //HRH_clip.SetActive (false);
        //HRL_clip.SetActive (false);
        //BPH_clip.SetActive (false);
        //BPL_clip.SetActive (false);
        //O2H_clip.SetActive (false);
        //O2L_clip.SetActive (false);
        //normal_clip.SetActive (false);

        NormalButton.onClick.AddListener (Normal_Pressed);
        NormalButton.gameObject.SetActive (false);
        Buttons.SetActive (false);
        //Buttons2.SetActive(false);
        Leg.SetActive(false);
        Leg2.SetActive(false);
        Leg3.SetActive(false);
        Leg4.SetActive(false);
        Circles.SetActive (false);
        Next.GetComponentInChildren<Text>().text = "Next";
        Next.gameObject.SetActive (false);
        if (distractor.trainingMode)
        {
            Buttons.GetComponentsInChildren<Button>()[0].onClick.AddListener(HRH_Pressed);
            Buttons.GetComponentsInChildren<Button>()[1].onClick.AddListener(HRL_Pressed);
            Buttons.GetComponentsInChildren<Button>()[2].onClick.AddListener(BPH_Pressed);
            Buttons.GetComponentsInChildren<Button>()[3].onClick.AddListener(BPL_Pressed);
            Buttons.GetComponentsInChildren<Button>()[4].onClick.AddListener(O2H_Pressed);
            Buttons.GetComponentsInChildren<Button>()[5].onClick.AddListener(O2L_Pressed);

            //Buttons2.GetComponentsInChildren<Button>()[0].onClick.AddListener(HRH_clip_Pressed);
            //Buttons2.GetComponentsInChildren<Button>()[1].onClick.AddListener(HRL_clip_Pressed);
            //Buttons2.GetComponentsInChildren<Button>()[2].onClick.AddListener(BPH_clip_Pressed);
            //Buttons2.GetComponentsInChildren<Button>()[3].onClick.AddListener(BPL_clip_Pressed);
            //Buttons2.GetComponentsInChildren<Button>()[4].onClick.AddListener(O2H_clip_Pressed);
            //Buttons2.GetComponentsInChildren<Button>()[5].onClick.AddListener(O2L_clip_Pressed);

            message = GetComponent<AudioSource>();
            VG = this.GetComponent<VibrationGenerator>();
            SetSelectedAmps(Application.dataPath + "/Data/" + distractor.subjectID + "/" + distractor.subjectID + "_" + "Amps.csv");
            monitorTexts = monitor.texts;

            Next.gameObject.SetActive(true);
            Next.GetComponentInChildren<Text>().text = "Next";
            Next.onClick.AddListener(Next_Pressed);
            T3.text = "(Intro)";
            T3.gameObject.SetActive(true);
            StartCoroutine(Normal());
            StartCoroutine(HRTestButton());
            StartCoroutine(BPTestButton());
            StartCoroutine(O2TestButton());

            //chagn these numbers
            if (distractor.general)
                section = 0;
            if (Graphical)
                section = 11;
            if (SwipeAlarm)
                section = 15;
            if (PulseAlarm)
                section = 23;
            if (SimulAlarm)
                section = 31;
        }
    }

    void SetSelectedAmps(string file_path)
    {
        StreamReader AmpsFile = new StreamReader(file_path);
        string selectedAmp;
        selectedAmp = AmpsFile.ReadLine ();
        VG.amp1 = float.Parse (selectedAmp);
        selectedAmp = AmpsFile.ReadLine ();
        VG.amp2 = float.Parse (selectedAmp);
        selectedAmp = AmpsFile.ReadLine ();
        VG.amp3 = float.Parse (selectedAmp);
        AmpsFile.Close( );  
    }

    void Next_Pressed(){
        section++;
        StartCoroutine (E_Training ());
    }
    void Normal_Pressed(){
        NormalPressed = true;
    }
    //void HRH_clip_Pressed(){
    //    StartCoroutine (PlayVideo ("HRH"));
    //}
    //void HRL_clip_Pressed(){
    //    StartCoroutine (PlayVideo ("HRL"));
    //}
    //void BPH_clip_Pressed(){
    //    StartCoroutine (PlayVideo ("BPH"));
    //}
    //void BPL_clip_Pressed(){
    //    StartCoroutine (PlayVideo ("BPL"));
    //}
    //void O2H_clip_Pressed(){
    //    StartCoroutine (PlayVideo ("O2H"));
    //}
    //void O2L_clip_Pressed(){
    //    StartCoroutine (PlayVideo ("O2L"));
    //}

    void HRH_Pressed(){
        HRHPressed = true;
    }
    void HRL_Pressed(){
        HRLPressed = true;
    }
    void BPH_Pressed(){
        BPHPressed = true;
    }
    void BPL_Pressed(){
        BPLPressed = true;
    }
    void O2H_Pressed(){
        O2HPressed = true;
    }
    void O2L_Pressed(){
        O2LPressed = true;
    }

    IEnumerator Normal(){
        while (!NormalPressed){
            yield return null;
        }
        //StartCoroutine (PlayVideo ("normal"));
        if (SimulAlarm)
        {
            StartCoroutine(VG.VibrateBeepSimul());
            yield return new WaitForSeconds(monitor.windowLength);
            if (!NormalPressed)
                yield break;
        }
        else
        {
            StartCoroutine(VG.VibrateBeep(0)); //O2 normal
            yield return new WaitForSeconds(monitor.windowLength);
            if (!NormalPressed)
                yield break;
            StartCoroutine(VG.VibrateBeep(1)); //BP normal
            yield return new WaitForSeconds(monitor.windowLength);
            if (!NormalPressed)
                yield break;
            StartCoroutine(VG.VibrateBeep(4)); //BP normal
            yield return new WaitForSeconds(monitor.windowLength);
            if (!NormalPressed)
                yield break;
        }
        StartCoroutine (Normal ());
        yield break;
    }
    IEnumerator HRTestButton(){
        while (!(HRHPressed || HRLPressed)){
            yield return null;
        }
        if (HRLPressed)
        {
            HRLPressed = false;
            VG.alarmLevel = "L";
        }
        else
        {
            HRHPressed = false;
            VG.alarmLevel = "H";
        }
        if (SwipeAlarm){
            StartCoroutine(VG.AlarmHRSwipe());
        }
        if(PulseAlarm){
            StartCoroutine(VG.AlarmHRPulse());
        }
        if(SimulAlarm){
            VG.correct = false;
            StartCoroutine(VG.AlarmHRNew());
            yield return new WaitForSeconds(3f);
            VG.correct = true;
        }
        yield return new WaitForSeconds (2f);
        StartCoroutine (HRTestButton ());
    }

    IEnumerator BPTestButton()
    {
        while (!(BPHPressed || BPLPressed))
        {
            yield return null;
        }
        if (BPLPressed)
        {
            BPLPressed = false;
            VG.alarmLevel = "L";
        }
        else
        {
            BPHPressed = false;
            VG.alarmLevel = "H";
        }
        if (SwipeAlarm)
        {
            StartCoroutine(VG.AlarmBPSwipe());
        }
        if (PulseAlarm)
        {
            StartCoroutine(VG.AlarmBPPulse());
        }
        if (SimulAlarm)
        {
            VG.correct = false;
            StartCoroutine(VG.AlarmBPNew());
            yield return new WaitForSeconds(3f);
            VG.correct = true;
        }
        yield return new WaitForSeconds(2f);
        StartCoroutine(BPTestButton());
    }

    IEnumerator O2TestButton()
    {
        while (!(O2HPressed || O2LPressed))
        {
            yield return null;
        }
        if (O2LPressed)
        {
            O2LPressed = false;
            VG.alarmLevel = "L";
        }
        else
        {
            O2HPressed = false;
            VG.alarmLevel = "H";
        }
        if (SwipeAlarm)
        {
            StartCoroutine(VG.AlarmO2Swipe());
        }
        if (PulseAlarm)
        {
            StartCoroutine(VG.AlarmO2Pulse());
        }
        if (SimulAlarm)
        {
            VG.correct = false;
            StartCoroutine(VG.AlarmO2New());
            yield return new WaitForSeconds(3f);
            VG.correct = true;
        }
        yield return new WaitForSeconds(2f);
        StartCoroutine(O2TestButton());
    } 


    //IEnumerator PlayVideo(string videoType){
    //    if (videoType == "normal") {
    //        normal_clip.SetActive (true);
    //        Buttons2.gameObject.SetActive (false);
    //        yield return new WaitForSeconds (1f);
    //        normal_clip.GetComponent<VideoPlayer> ().Play ();
    //    }

    //    if (videoType == "O2L") {
    //        O2L_clip.SetActive (true);
    //        Buttons2.gameObject.SetActive (false);
    //        yield return new WaitForSeconds (1f);
    //        O2L_clip.GetComponent<VideoPlayer> ().Play ();
    //        yield return new WaitForSeconds (10f);
    //        O2L_clip.SetActive (false);
    //        Buttons2.gameObject.SetActive (true);
    //    }
    //    if (videoType == "O2H") {
    //        O2H_clip.SetActive (true);
    //        Buttons2.gameObject.SetActive (false);
    //        yield return new WaitForSeconds (1f);
    //        O2H_clip.GetComponent<VideoPlayer> ().Play ();
    //        yield return new WaitForSeconds (10f);
    //        O2H_clip.SetActive (false);
    //        Buttons2.gameObject.SetActive (true);
    //    }
    //    if (videoType == "BPL") {
    //        BPL_clip.SetActive (true);
    //        Buttons2.gameObject.SetActive (false);
    //        yield return new WaitForSeconds (1f);
    //        BPL_clip.GetComponent<VideoPlayer> ().Play ();
    //        yield return new WaitForSeconds (10f);
    //        BPL_clip.SetActive (false);
    //        Buttons2.gameObject.SetActive (true);
    //    }
    //    if (videoType == "BPH") {
    //        BPH_clip.SetActive (true);
    //        Buttons2.gameObject.SetActive (false);
    //        yield return new WaitForSeconds (1f);
    //        BPH_clip.GetComponent<VideoPlayer> ().Play ();
    //        yield return new WaitForSeconds (10f);
    //        BPH_clip.SetActive (false);
    //        Buttons2.gameObject.SetActive (true);
    //    }
    //    if (videoType == "HRH") {
    //        HRH_clip.SetActive (true);
    //        Buttons2.gameObject.SetActive (false);
    //        yield return new WaitForSeconds (1f);
    //        HRH_clip.GetComponent<VideoPlayer> ().Play ();
    //        yield return new WaitForSeconds (10f);
    //        HRH_clip.SetActive (false);
    //        Buttons2.gameObject.SetActive (true);
    //    }
    //    if (videoType == "HRL") {
    //        HRL_clip.SetActive (true);
    //        Buttons2.gameObject.SetActive (false);
    //        yield return new WaitForSeconds (1f);
    //        HRL_clip.GetComponent<VideoPlayer> ().Play ();
    //        yield return new WaitForSeconds (10f);
    //        HRL_clip.SetActive (false);
    //        Buttons2.gameObject.SetActive (true);
    //    }
    //}


    void TextDisappear(){
        T1.gameObject.SetActive (false);
        T2.gameObject.SetActive (false);
    }

    IEnumerator ShowThisText(string textT1, string textT2){
        Next.gameObject.SetActive (false);
        TextDisappear ();
        T1.text = textT1;
        T1.gameObject.SetActive (true);
        yield return new WaitForSeconds (1f);
        T2.text = textT2;
        T2.gameObject.SetActive (true);
        yield return new WaitForSeconds (2f);
        Next.gameObject.SetActive (true);
    }

    public IEnumerator E_Training(){
        while (section > 40) 
            yield return null;

        if (section == 1) {
            StartCoroutine (ShowThisText ("Introduction", "In this experiment, you will play the role of a surgeon " +
            "who is monitoring a patient."));
        }

        if (section == 2) {
            StartCoroutine(ShowThisText( "Your Role", "Your job is to note whenever your patient’s vital signs become abnormal. " +
                "The information about your patient is transferred to you in different ways."));
        }

        if (section == 3)
        {
            StartCoroutine(ShowThisText("Experiment Blocks", "The experiment has four blocks, in each, the way to receive information about the patient is different. " +
                                        "Before starting each of these blocks, you will be presented with a separated training section."));
        }

        if (section == 4)
        {
            StartCoroutine(ShowThisText("Main Task", "Since you are a doctor, " +
                "you are not just sitting around watching your patient’s vital signs. " +
                "In the meanwhile, your main task is to look at the circles that will appear on this screen and " +
                "tap the ones that light up red \"as quickly as you can\". "));
            yield return new WaitForSeconds(2f);
            Circles.SetActive(true);
        }

        if (section == 5)
        {
            Circles.SetActive(false);
            StartCoroutine(ShowThisText("Recording Answers", "While you are tapping the circles " +
                "when there's an abnoraml situation in the patient's vital signs, you have to record it \"as quickly as you can\" " +
                "using one of the six blue buttons on the top right of this screen."));

            monitor.RespondingButtons.SetActive(true);
        }

        if (section == 6)
        {
            StartCoroutine(ShowThisText("Recording Answers", "A little blue circle indicates that your click was successfull " +
                                        "(this is NOT a feedback about the correctness of your answer). " +
                                        "If you did not see the indication, please click again."));
        }
       


        if (section == 7)
        {
            monitor.RespondingButtons.SetActive(false);
            StartCoroutine(ShowThisText("Recording Answers", "When you respond correctly, the abnormal vital sign will become normal again." +
                "Otherwise, it will stay abnormal until you respond correctly. " +
                "So it is VERY IMPORTANT to change your resposne if the alarm conditions is repeating."));
        }

        if (section == 8)
        {
            StartCoroutine(ShowThisText("Try a couple of scenarios", "Now we’ll try everything together. " +
                "You will also start hearing the background sound of a hospital, from other doctors and other patients. " +
                "These other alarms, talking, and sounds are not related to your patient, so you should ignore them."));
            print("*************************************START*************************************");
        }

        if (section == 9)
        {
            Next.gameObject.SetActive(false);
            TextDisappear();
            T1.text = "You can now proceed with starting the first block.";
            T1.gameObject.SetActive(true);
        }



        //Visual Display
        if (section == 12) {
            StartCoroutine(ShowThisText("Patient Monitor", "In this block, the monitor to your upper right on the wall in front of you" +
                                        " shows your patient’s vital signs. " +
                "When a parameter is normal it is shown with the letter N in front of it (they are all normal right now). " +
                "When the vital becomes high or low the indication changes to ↑ or ↓."));
            monitor.ResetVitalsToNormalAndShow ();
            monitorTexts.SetActive (true);
        }
        if (section == 13)
        {
            StartCoroutine(ShowThisText("Auditory Alarm", "In addition to the indication on the " +
                "visual display, you will also hear an auditory alarm as an extra indication that one of the vitals in abnormal." +
                "You will hear the sound now."));
            yield return new WaitForSeconds(10f);
            message.clip = messages[0];
            message.Play();
            yield return new WaitForSeconds(message.clip.length + 1f);
            //yield return new WaitForSeconds (1f);
        }
        if (section == 14)
        {
            Next.gameObject.SetActive(false);
            TextDisappear();
            T1.text = "START";
            T2.text = "You will now start a short trial version of this block, a break, and then the main experiment.";
            T1.gameObject.SetActive(true);
            T2.gameObject.SetActive(true);
        }



        //Vibratons Swipe
        if (section == 16) {
            StartCoroutine (ShowThisText ("Vibrations to your Leg", "In this section, patient's information is delivered through vibrations to your leg."));
        }

        if (section == 17)
        {
            StartCoroutine(ShowThisText("Vibrations", "On the vibrations there are two pieces of information: " +
                "type of the vital signs and the level of them on that moment."));
        }


        if (section == 18) {
            StartCoroutine (ShowThisText ("Type", "The location of each of the bands corresponds to the type of the vital sign as you see in this picture. " +
                                          "You would have to memorize these!"));
            Leg.SetActive (true);
        }

        if (section == 19) {
            Leg.SetActive (false);
            StartCoroutine(ShowThisText( "Level - Normal", "When the level is normal, each of the bands vibrates continuously after the other." +
                " Click the \"Normal\" button to experience it."));
            NormalButton.gameObject.SetActive (true);
        }


        if (section == 20) {
            NormalPressed = false;
            //normal_clip.SetActive (false);
            NormalButton.gameObject.SetActive (false);
            StartCoroutine (ShowThisText ("Level - Abnormal", "When one of the vital signs becomes abnormal, " +
                "the normal signal\t changes to a swipe up/down vibration for high/low following by an indicative vibration on that band. " +
                "You can try this by clicking on each of the conditions on the next page."));
        }
        if (section == 21) {
            Leg4.SetActive (true);
            Next.gameObject.SetActive (false);
            TextDisappear ();
            Buttons.SetActive (true);
            yield return new WaitForSeconds (2f);
            Next.gameObject.SetActive (true);
        }
        if (section == 22)
        {
            Next.gameObject.SetActive(false);
            Leg4.SetActive(false);
            Buttons.SetActive(false);
            //Buttons2.SetActive(false);
            TextDisappear();
            T1.text = "START";
            T2.text = "You will now start a short trial version of this block, a break, and then the main experiment.";
            T1.gameObject.SetActive(true);
            T2.gameObject.SetActive(true);
        }




        //Vibratons Pulse
        if (section == 24)
        {
            StartCoroutine(ShowThisText("Vibrations to your Leg", "In this section, patient's information is delivered through vibrations to your leg."));
        }

        if (section == 25)
        {
            StartCoroutine(ShowThisText("Vibrations", "On the vibrations there are two pieces of information: " +
                "type of the vital signs and the level of them on that moment."));
        }


        if (section == 26)
        {
            StartCoroutine(ShowThisText("Type", "The location of each of the bands corresponds to the type of the vital sign as you see in this picture. " +
                                        "You would have to memorize these!"));
            Leg.SetActive(true);
        }

        if (section == 27)
        {
            Leg.SetActive(false);
            StartCoroutine(ShowThisText("Level - Normal", "When the level is normal, each of the bands vibrates continuously after the other." +
                " Click the \"Normal\" button to experience it."));
            NormalButton.gameObject.SetActive(true);
        }


        if (section == 28)
        {
            NormalPressed = false;
            //normal_clip.SetActive(false);
            NormalButton.gameObject.SetActive(false);
            StartCoroutine(ShowThisText("Level - Abnormal", "When one of the vital signs becomes abnormal, " +
                "the normal vibration changes to a double pulse for low and a triple pulse for high."));
        }

        if (section == 29)
        {
            Next.gameObject.SetActive(false);
            TextDisappear();
            Buttons.SetActive(true);
            Leg2.SetActive(true);
            yield return new WaitForSeconds(2f);
            Next.gameObject.SetActive(true);
        }
        if (section == 30)
        {
            Next.gameObject.SetActive(false);
            Buttons.SetActive(false);
            Leg2.SetActive(false);
            TextDisappear();
            T1.text = "START";
            T2.text = "You will now start a short trial version of this part, a break, and then the main section.";
            T1.gameObject.SetActive(true);
            T2.gameObject.SetActive(true);
        }


        //Vibratons Simultaneous
        if (section == 32)
        {
            StartCoroutine(ShowThisText("Vibrations to your Leg", "In this section, patient's information is delivered through vibrations to your leg."));
        }

        if (section == 33)
        {
            StartCoroutine(ShowThisText("Vibrations", "On the vibrations there are two pieces of information: " +
                "type of the vital signs and the level of them on that moment."));
        }


        if (section == 34)
        {
            StartCoroutine(ShowThisText("Type", "The location of each of the bands corresponds to the type of the vital sign as you see in this picture. " +
                                        "You would have to memorize these!"));
            Leg.SetActive(true);
        }

        if (section == 35)
        {
            Leg.SetActive(false);
            StartCoroutine(ShowThisText("Level - Normal", "While the level is normal, the bands do not vibrate and remain silent."));
            //NormalButton.gameObject.SetActive(true);
        }


        if (section == 36)
        {
            //NormalPressed = false;
            //NormalButton.gameObject.SetActive(false);
            StartCoroutine(ShowThisText("Level - Abnormal", "When one of the vital signs becomes abnormal, " +
                "the band corresponding to the abnormal sign delivers the alarm state. " +
                                        "The alarm state continues until you record it correctly."));
        }

        if (section == 37)
        {
            Leg3.SetActive(true);
            Next.gameObject.SetActive(false);
            TextDisappear();
            Buttons.SetActive(true);
            yield return new WaitForSeconds(2f);
            Next.gameObject.SetActive(true);
        }
        if (section == 38)
        {
            Next.gameObject.SetActive(false);
            Buttons.SetActive(false);
            Leg3.SetActive(false);
            TextDisappear();
            T1.text = "START";
            T2.text = "You will now start a short trial version of this part, a break, and then the main section.";
            T1.gameObject.SetActive(true);
            T2.gameObject.SetActive(true);
        }


    }
}